
/*
 * Copyright (C) 2025 Web Server LLC
 */


#include <ngx_config.h>
#include <ngx_core.h>


ngx_time_t  ngx_build_time = { .sec = ANGIE_BUILD_TIMESTAMP };
